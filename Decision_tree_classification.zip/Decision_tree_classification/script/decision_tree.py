# decision_tree.py
# Decision Tree Classification on Weather Dataset

import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
import matplotlib.pyplot as plt

# ------------------------
# Step 1: Create Dataset
# ------------------------
data = {
    'Weather': ['Sunny', 'Sunny', 'Sunny', 'Cloudy', 'Cloudy', 'Cloudy', 'Cloudy', 'Rainy', 'Rainy', 'Rainy'],
    'Humidity': ['High', 'Normal', 'Normal', 'High', 'High', 'Normal', 'Normal', 'High', 'Normal', 'Normal'],
    'Wind': ['Week', 'Week', 'Strong', 'Week', 'Strong', 'Strong', 'Week', 'Week', 'Strong', 'Week'],
    'Play': ['No', 'No', 'No', 'No', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes']
}

df = pd.DataFrame(data)
print("Original Dataset:\n", df)

# ------------------------
# Step 2: Encode categorical values
# ------------------------
le = LabelEncoder()
for col in df.columns:
    df[col] = le.fit_transform(df[col])

print("\nEncoded Dataset:\n", df)

# ------------------------
# Step 3: Features (X) and Target (y)
# ------------------------
X = df[['Weather', 'Humidity', 'Wind']]
y = df['Play']

# ------------------------
# Step 4: Train Decision Tree
# ------------------------
model = DecisionTreeClassifier(criterion='entropy')
model.fit(X, y)

# ------------------------
# Step 5: Test Prediction
# Example input: Weather=Sunny, Humidity=Normal, Wind=Week
sample = [[2, 1, 1]]  
prediction = model.predict(sample)
print("\nPrediction for (Sunny, Normal, Week):", prediction)

# ------------------------
# Step 6: Visualize Decision Tree
# ------------------------
plt.figure(figsize=(10, 6))
tree.plot_tree(model,
               feature_names=['Weather', 'Humidity', 'Wind'],
               class_names=['No', 'Yes'],
               filled=True)
plt.show()