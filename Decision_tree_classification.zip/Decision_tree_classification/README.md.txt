# Decision Tree Classification on Weather Data

This project demonstrates a simple Decision Tree Classification model using Python's scikit-learn library. The model predicts whether to play (Yes/No) based on weather conditions.

## Dataset

The dataset contains 10 records with the following features:

- Weather: Sunny, Cloudy, Rainy
- Humidity: High, Normal
- Wind: Week, Strong
- Play: Target variable (Yes/No)

Example data:

| Weather | Humidity | Wind  | Play |
|---------|---------|-------|------|
| Sunny   | High    | Week  | No   |
| Sunny   | Normal  | Week  | No   |
| Cloudy  | High    | Week  | No   |
| Rainy   | Normal  | Strong| Yes  |

The dataset is stored in weather_data.csv.

## Requirements

- Python 3.x
- pandas
- scikit-learn
